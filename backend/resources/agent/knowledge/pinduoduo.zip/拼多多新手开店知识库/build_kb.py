# -*- coding: utf-8 -*-
"""拼多多新手开店课堂知识库构建脚本：raw JSONL -> 每课Markdown + Excel索引 + README"""
import json, pathlib, re, datetime, html2text
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter

BASE = pathlib.Path(__file__).resolve().parent
RAW = BASE / "raw/courses.jsonl"
MERGED = BASE / "_merged_list.json"
OUT_MD = BASE / "课程正文"

TYPE = {0: "图文课", 1: "视频课", 2: "直播课"}
# 主分类展示顺序
CAT_ORDER = ["开店流程", "商品发布", "发货操作", "账号与资金", "平台规则", "社区团购"]

def sanitize(name, maxlen=80):
    name = re.sub(r'[\\/:*?"<>|#]', "_", name)
    name = re.sub(r"\s+", " ", name).strip()
    return name[:maxlen] or "untitled"

def ms_to_date(ms):
    if not ms: return ""
    try:
        return datetime.datetime.fromtimestamp(ms/1000).strftime("%Y-%m-%d")
    except Exception:
        return ""

def fmt_dur(sec):
    if not sec: return ""
    sec = int(sec)
    m, s = divmod(sec, 60)
    h, m = divmod(m, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"

# 载入原始课程
courses = {}
for line in RAW.read_text(encoding="utf-8").splitlines():
    if not line.strip(): continue
    c = json.loads(line)
    if c and c.get("id"):
        courses[c["id"]] = c

# 载入清单（分类标签、列表标签、学习人数）
merged = {c["id"]: c for c in json.loads(MERGED.read_text(encoding="utf-8"))}

h = html2text.HTML2Text()
h.ignore_images = False
h.ignore_links = False
h.body_width = 0
h.unicode_snob = True

records = []
md_index = {}  # id -> relative md path

for cid, c in courses.items():
    m = merged.get(cid, {})
    modules = m.get("modules", [])
    primary = modules[0] if modules else "未分类"
    ctype = TYPE.get(c.get("contentType"), "未知")
    title = c.get("courseName") or c.get("promotionName") or f"课程{cid}"
    author = c.get("author") or ""
    learners = c.get("readCountStr") or m.get("learners", "")
    desc = (c.get("description") or "").strip()
    tags = c.get("tags") or m.get("tags") or []
    if isinstance(tags, str): tags = [tags]
    created = ms_to_date(c.get("createdAt"))
    score = c.get("averageScore")
    body_html = c.get("textContent") or ""
    body_md = h.handle(body_html).strip() if body_html else ""

    # 元信息块
    meta = []
    meta.append(f"- 课程ID：{cid}")
    meta.append(f"- 课程类型：{ctype}")
    meta.append(f"- 所属分类：{' / '.join(modules) if modules else '未分类'}")
    meta.append(f"- 讲师/作者：{author}")
    meta.append(f"- 学习人数：{learners}")
    if score is not None: meta.append(f"- 评分：{score}")
    if tags: meta.append(f"- 标签：{', '.join(map(str, tags))}")
    if created: meta.append(f"- 上线时间：{created}")
    if c.get("courseTarget"): meta.append(f"- 适用对象：{c.get('courseTarget')}")
    if desc: meta.append(f"- 简介：{desc}")
    if ctype == "视频课" and c.get("videoUrl"):
        meta.append(f"- 视频时长：{fmt_dur(c.get('videoLengthSeconds'))}")
        meta.append(f"- 视频地址：{c.get('videoUrl')}")
    if ctype == "直播课":
        if c.get("liveStartTime"): meta.append(f"- 直播开始：{ms_to_date(c.get('liveStartTime'))}")
        if c.get("liveEndTime"): meta.append(f"- 直播结束：{ms_to_date(c.get('liveEndTime'))}")
        if c.get("streamRecordAddr"): meta.append(f"- 回放地址：{c.get('streamRecordAddr')}")
        if c.get("chatRecordAddr"): meta.append(f"- 聊天记录：{c.get('chatRecordAddr')}")
    if c.get("practicalResourceUrl"):
        meta.append(f"- 配套工具/资源：{c.get('practicalResourceUrl')}")
    meta.append(f"- 原文链接：https://mms.pinduoduo.com/daxue/detail?courseId={cid}")

    parts = [f"# {title}", "", "## 课程信息", ""] + meta
    if body_md:
        parts += ["", "## 课程正文", "", body_md]
    elif ctype == "图文课":
        parts += ["", "## 课程正文", "", "（该课程无图文正文，详见原文链接）"]
    else:
        parts += ["", "## 说明", "", "本课程为" + ctype + "，正文为视频/直播，此处仅保留元信息与链接，视频语音未做转写。"]

    folder = OUT_MD / primary
    folder.mkdir(parents=True, exist_ok=True)
    fname = sanitize(f"{cid}_{title}") + ".md"
    fpath = folder / fname
    fpath.write_text("\n".join(parts) + "\n", encoding="utf-8")
    rel = fpath.relative_to(BASE)
    md_index[cid] = rel.as_posix()

    records.append({
        "id": cid, "title": title, "primary": primary,
        "modules": "、".join(modules), "type": ctype, "author": author,
        "learners": learners, "score": score if score is not None else "",
        "tags": ", ".join(map(str, tags)), "created": created,
        "desc": desc, "duration": fmt_dur(c.get("videoLengthSeconds")) if ctype == "视频课" else "",
        "video": c.get("videoUrl") or "", "resource": c.get("practicalResourceUrl") or "",
        "url": f"https://mms.pinduoduo.com/daxue/detail?courseId={cid}",
        "md": rel.as_posix(),
    })

# ---------- Excel 索引 ----------
wb = Workbook()
ws = wb.active
ws.title = "课程索引"
headers = ["课程ID","标题","主分类","所属分类","类型","作者","学习人数","评分","标签","上线时间","视频时长","简介","配套资源","视频地址","原文链接","正文文件"]
ws.append(headers)
head_fill = PatternFill("solid", fgColor="305496")
for col, _ in enumerate(headers, 1):
    cell = ws.cell(1, col)
    cell.font = Font(bold=True, color="FFFFFF")
    cell.fill = head_fill
    cell.alignment = Alignment(horizontal="center", vertical="center")

# 按主分类、ID排序
records.sort(key=lambda r: (CAT_ORDER.index(r["primary"]) if r["primary"] in CAT_ORDER else 99, r["id"]))
for r in records:
    ws.append([r["id"], r["title"], r["primary"], r["modules"], r["type"], r["author"],
               r["learners"], r["score"], r["tags"], r["created"], r["duration"],
               r["desc"], r["resource"], r["video"], r["url"], r["md"]])

widths = [9,42,10,16,8,14,12,7,18,11,9,40,28,30,34,34]
for i, w in enumerate(widths, 1):
    ws.column_dimensions[get_column_letter(i)].width = w
ws.freeze_panes = "A2"
ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{len(records)+1}"
xlsx = BASE / "拼多多新手开店课程索引.xlsx"
wb.save(xlsx)

# ---------- README ----------
from collections import Counter, defaultdict
by_cat = defaultdict(list)
for r in records:
    by_cat[r["primary"]].append(r)
type_count = Counter(r["type"] for r in records)

lines = ["# 拼多多课堂 · 新手开店知识库", "",
         f"> 来源：拼多多商家后台「拼多多课堂」新手开店板块，采集时间 2026-10-21。",
         f"> 共收录 **{len(records)}** 门课程（图文课 {type_count.get('图文课',0)}、视频课 {type_count.get('视频课',0)}、直播课 {type_count.get('直播课',0)}）。",
         "", "## 目录结构", "",
         "- `课程正文/<分类>/`：每门课一个 Markdown 文件，含课程信息与图文正文。",
         "- `拼多多新手开店课程索引.xlsx`：全量课程索引（可按分类/类型/标签筛选）。",
         "- `raw/courses.jsonl`：接口原始课程 JSON（留档，便于复核）。",
         "", "## 分类统计", ""]
for cat in CAT_ORDER:
    if cat in by_cat:
        lines.append(f"- **{cat}**：{len(by_cat[cat])} 门")
lines += ["", "## 分类课程清单", ""]
for cat in CAT_ORDER:
    if cat not in by_cat: continue
    lines.append(f"### {cat}（{len(by_cat[cat])}门）")
    lines.append("")
    lines.append("| ID | 标题 | 类型 | 作者 | 学习人数 | 正文 |")
    lines.append("|---|---|---|---|---|---|")
    for r in sorted(by_cat[cat], key=lambda x: x["id"]):
        link = f"[打开]({r['md']})"
        title = r["title"].replace("|", "丨")
        lines.append(f"| {r['id']} | {title} | {r['type']} | {r['author']} | {r['learners']} | {link} |")
    lines.append("")
lines += ["## 说明", "",
          "- 视频课/直播课仅收录标题、简介、讲师、时长与原始视频/回放链接，未对语音做转写。",
          "- 课程正文图片为拼多多 CDN 远程链接，联网时可正常显示。",
          "- 「入门必学」(moduleId=217) 为虚拟导航节点，单独访问无独立课程列表，故课程按其实际归属子分类归档。",
          ""]
(BASE / "README.md").write_text("\n".join(lines), encoding="utf-8")

print("课程数:", len(records))
print("类型:", dict(type_count))
print("分类:", {k: len(v) for k, v in by_cat.items()})
print("Excel:", xlsx.name)
