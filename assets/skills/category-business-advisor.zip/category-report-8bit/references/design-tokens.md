# Design Tokens：8-BIT ORBIT

## 色板（:root 变量，整站唯一来源）

```css
:root{
  --void:#0A0E27; --navy:#0F1B3D; --navy2:#14204a;
  --cyan:#5EDCF4; --pink:#F0A6CA; --yellow:#F4D03F; --lavender:#E2D5F2;
  --white:#FFFFFF;
  --paper:var(--void); --card:var(--navy); --ink:var(--white); --sub:rgba(255,255,255,0.72); --faint:rgba(255,255,255,0.5);
  --line:rgba(94,220,244,0.22); --line-soft:rgba(94,220,244,0.12);
  --accent:var(--cyan); --green:var(--cyan); --amber:var(--yellow); --red:var(--pink);
  --accent-bg:rgba(94,220,244,0.14); --green-bg:rgba(94,220,244,0.14); --amber-bg:rgba(244,208,63,0.14); --red-bg:rgba(240,166,202,0.14);
  --font-cjk:"Noto Sans SC",-apple-system,"PingFang SC",sans-serif;
  --font-mono:"Space Mono","Noto Sans SC",monospace;
}
```

- `--void`：页面底色（深空蓝黑），`--navy`：卡片/容器底，`--navy2`：表头等更深层级。
- 语义映射：`--green`=青（GO/优势）、`--amber`=黄（谨慎/警告）、`--red`=粉（回避/风险）。保留变量名 `green/amber/red/accent` 是为了兼容旧 HTML 内联样式（`style="color:var(--red)"` 等自动生效）。
- `--line` 系用青色低透明，不用纯灰——分隔线、虚线边框统一走它。

## 字体

```html
<link rel="stylesheet" href="https://miaoda.feishu.cn/fonts/css2?family=Noto+Sans+SC:wght@400;500;700;900&family=Space+Mono:wght@400;700&display=swap">
```

- 禁止直连 `fonts.googleapis.com` / `fonts.gstatic.com`（部分地区不可达）。
- `--font-cjk`：正文/标题/中文（Noto Sans SC 900 用于标题）；`--font-mono`：HUD、编号、数字、英文标签（Space Mono + letter-spacing 0.1em~0.3em）。
- 每个 font-family 必须带系统 fallback（如上）。

## 背景装饰层（body 伪元素，不占文档流）

```css
body{background:var(--void);color:var(--ink);font-family:var(--font-cjk);font-size:15px;line-height:1.75;cursor:crosshair;}
body::before{content:"";position:fixed;inset:0;z-index:0;pointer-events:none;
  background-image:linear-gradient(rgba(94,220,244,0.055) 1px,transparent 1px),linear-gradient(90deg,rgba(94,220,244,0.055) 1px,transparent 1px);
  background-size:40px 40px;}   /* 网格 */
body::after{content:"";position:fixed;inset:0;z-index:0;pointer-events:none;
  background:repeating-linear-gradient(0deg,transparent 0px,transparent 2px,rgba(10,14,39,0.05) 2px,rgba(10,14,39,0.05) 4px);}  /* 扫描线 */
.wrap{position:relative;z-index:1;max-width:1040px;margin:0 auto;padding:0 20px;}
```

- 装饰层 opacity 控制在 0.05 级别，保证正文对比度。
- 可选增强（参照路演页，报告默认不加）：星场、像素粒子、角标括号 `border-top/left:4px solid var(--cyan)`、CRT 辉光径向渐变。

## 硬阴影与像素感规则

- 组件一律**无圆角**；层次感来自像素硬阴影：`box-shadow:4px 4px 0 rgba(0,0,0,0.35)`（小件）或 `8px 8px 0 var(--yellow)`（结论横幅等强调块）。
- 标题硬阴影：`text-shadow:4px 4px 0 var(--yellow),8px 8px 0 var(--navy)`（黄 + 深底两层，参照路演 h1）。
- 强调块（verdict/judge）可做"青边框 + 黄 8px 阴影"双色像素窗。
- 边框风格：常规组件 `2px solid var(--line)`；章节分隔用 `2px dashed var(--line)`；行内分隔 `1px dashed var(--line-soft)`。

## favicon（内联 SVG，像素方块）

```html
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' fill='%230F1B3D'/%3E%3Crect x='5' y='5' width='9' height='9' fill='%235EDCF4'/%3E%3Crect x='18' y='5' width='9' height='9' fill='%23F4D03F'/%3E%3Crect x='5' y='18' width='9' height='9' fill='%23F0A6CA'/%3E%3Crect x='18' y='18' width='9' height='9' fill='%23FFFFFF'/%3E%3C/svg%3E">
```
