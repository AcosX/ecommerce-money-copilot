# ECharts 霓虹主题

图表只改颜色与辅助线，**不改数据、不改图型**。统一 palette：

```js
var palette={
  ink:'#ffffff',                       // 轴标签/散点标签主色
  sub:'rgba(255,255,255,0.62)',        // 次级文字
  line:'rgba(94,220,244,0.18)',        // 网格线/坐标线
  accent:'#5EDCF4',                    // 主强调（青）
  green:'#5EDCF4',                     // GO/优势（青，变量名沿用语义）
  amber:'#F4D03F',                     // 谨慎/警告（黄）
  red:'#F0A6CA',                       // 回避/风险（粉）
  muted:'#3f5078'                      // 中性/其他（深蓝灰）
};
```

## 通用配置

- 柱/条形：`barWidth` 保留原值；强调数据用 `accent`（青），中性/参照用 `muted`，警示档用 `amber`/`red`。
- `label`（数据标注）：`color:palette.sub`，保持 position 不变。
- `xAxis/yAxis`：`axisLabel:{color:palette.sub}`，`splitLine:{lineStyle:{color:palette.line}}`，`axisLine:{show:false}`（保留原配置结构，只换颜色）。
- 轴 `name` 文字：`color:palette.sub`。
- 分类轴数据、数值、坐标 min/max、markLine 位置一律不动。

## 图型适配示例

### 1 横向条形（规模/份额/动机）

```js
xAxis:{type:'value',max:100,axisLabel:{color:palette.sub,formatter:'{value}%'},splitLine:{lineStyle:{color:palette.line}},axisLine:{show:false}},
yAxis:{type:'category',data:[...],axisLabel:{color:palette.ink,fontSize:13},axisLine:{show:false},axisTick:{show:false}},
series:[{type:'bar',barWidth:22,data:[
  {value:73.4,itemStyle:{color:palette.muted}},
  {value:4.8,itemStyle:{color:palette.amber}},
  {value:21.8,itemStyle:{color:palette.accent}}
],label:{show:true,position:'right',color:palette.sub,formatter:'{c}%'}}]
```

### 2 散点四象限（吸引力 × 可进入性）

```js
xAxis:{type:'value',min:0,max:10,name:'个人可进入性 →',nameLocation:'middle',nameGap:28,axisLabel:{color:palette.sub},splitLine:{show:false},axisLine:{lineStyle:{color:palette.line}}},
yAxis:{type:'value',min:0,max:10,name:'市场吸引力 ↑',nameLocation:'middle',nameGap:38,axisLabel:{color:palette.sub},splitLine:{show:false},axisLine:{lineStyle:{color:palette.line}}},
series:[{
  type:'scatter',symbolSize:16,
  data:pts.map(function(p){return {value:p.v,name:p.name,itemStyle:{color:p.c}};}),
  label:{show:true,position:'right',color:palette.ink,fontSize:12.5,formatter:'{b}'},
  markLine:{silent:true,symbol:'none',lineStyle:{color:'rgba(255,255,255,0.28)',type:'dashed'},data:[{xAxis:5},{yAxis:5}]},
  markArea:{silent:true,itemStyle:{color:'rgba(94,220,244,0.09)'},data:[[{xAxis:5,yAxis:5},{xAxis:10,yAxis:10}]]}
}]
```

- 散点颜色：机会点用 `green`（青）、谨慎用 `amber`（黄）、回避用 `red`（粉）。
- 分割线：`rgba(255,255,255,0.28)` 虚线；高亮区：`rgba(94,220,244,0.09)`。

## 检查项

- 深底上标签必须可见：凡原来 `color:'#22262b'` 类的深色文字一律换 `palette.ink`（白）或 `palette.sub`。
- 硬编码的浅底背景色（如 `rgba(47,125,91,0.06)` 绿高亮）换为青 `rgba(94,220,244,0.09)` 系。
- 不改 tooltip 结构；如要样式，背景深色 `#0F1B3D` + 白字，边框青色。
- resize 监听、容器 id、setOption 结构保持原样。
